const TRANSFORMATION_TYPES = [
    { title: 'Sin espacios', value: 'Sin_espacios' },
    { title: 'Sin espacios y mayuscula', value: 'Sin_espacios_mayusc' },
    { title: 'Sin espacios y minuscula', value: 'Sin_espacios_minus' },

  ];
  
  module.exports = { TRANSFORMATION_TYPES };
  