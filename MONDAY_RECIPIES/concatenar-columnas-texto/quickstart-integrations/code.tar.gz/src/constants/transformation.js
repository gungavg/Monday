const TRANSFORMATION_TYPES = [
  { title: 'to upper case', value: 'TO_UPPER_CASE' },

];

module.exports = { TRANSFORMATION_TYPES };
